# Xmrig modified for MonerooceaN pool on windows

This is a miner that is personalised for **Asimwe Landry** by **Asimwe Landry**

## Configuration

* replace the ```"C:\"``` in the start_miner file w\ the path to the file xmrig
* Make sure that you computer is running on a stable network
* after you've secured the internet stability then run the start_miner.bat file
* then minimise the CMD 
* run xmrig.exe for the second time minimuse it leave it

## Schedule

* Use ```win``` key to and search ``` task scheduler ```
* look for **Create Basic task**
* click the tab and init the task creation
* name **study reminder**
* press next button
* on the trigger tab check the **when computer starts**
* press next
* keep the default start program option
* press next
* process browse and find the file start_miner.bat for your study schuduler to be executed each time to start the computer
* and the press Finish and let your computer cook

## config -t

* open the config file
* press ```ctrl + f```
* type daemon in the input field and check it the value is **true** is not delete false and type true as replacement
 
```note
The scheduler is not that importance but it is way better with it
```

git 

## **You will never get distructed again while the program is running in you computer**

## created with love and heart by Asimwe Landry

#### Please leave a like on this repository